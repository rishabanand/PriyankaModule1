 1. CREATE table customer1(
Customer_Id number(5)  NOT NULL PRIMARY KEY,
Cust_Name  varchar2(30),
Address1 varchar2(30),
Address2 varchar2(30)
);


2.ALTER table customer1 MODIFY Cust_Name Varchar2(30); 

ALTER table customer1
ADD(Gender varchar2(1),
AGE number(3),
PhoneNo number(10),
Email varchar2(30);


3.ALTER TABLE customer1 DROP COLUMN Email;


4.CREATE table AccountsMaster(
AccountNumber number(10,2)  CONSTRAINT Acc_pk PRIMARY KEY,
Customer_Id  number(5) CONSTRAINT CustomerId_fk REFERENCES customer1(Customer_Id) ,
AccountType varchar2(3),
LedgerBalance number(10,2)
);


7.CREATE SEQUENCE seq_Customer Start WITH 1000
INCREMENT BY;
INSERT INTO customer VALUES(seq.Customer.NEXTVAL,'Smith','46 Lane','New York');