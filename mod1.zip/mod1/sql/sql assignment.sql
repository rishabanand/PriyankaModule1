 1. CREATE table customer1(
Customer_Id number(5)  NOT NULL PRIMARY KEY,
Cust_Name  varchar2(30),
Address1 varchar2(30),
Address2 varchar2(30)
);


2.ALTER table customer1 MODIFY Cust_Name Varchar2(30); 

ALTER table customer1
ADD(Gender varchar2(1),
AGE number(3),
PhoneNo number(10),
Email varchar2(30);


3.ALTER TABLE customer1 DROP COLUMN Email;


4.CREATE table AccountsMaster(
AccountNumber number(10,2)   PRIMARY KEY,
Customer_Id  number(5) CONSTRAINT CustomerId_fk REFERENCES customer1(Customer_Id) ,
AccountType varchar2(3),
LedgerBalance number(10,2)
);

5.ALTER table AccountSMaster ADD CHECK(AccountType='NRI' OR AccountType='IND');

6.ALTER table AccountSMaster  ADD CONSTRAINTS Balance_Chk CHECK(LedgerBalance>5000);

7.CREATE SEQUENCE seq_Customer START WITH 1000
INCREMENT BY 1;
INSERT INTO customer1 VALUES(seq_Customer.NEXTVAL,'Smith','46,Lane 1','New York','M','32','7890893433');
INSERT INTO customer1 VALUES(seq_Customer.NEXTVAL,'Jack','89, Lane 9','New York','M','35','6690233433');
INSERT INTO customer1 VALUES(seq_Customer.NEXTVAL,'Mary','78, Lane 5','Washington','F','39','8990893433');
INSERT INTO customer1 VALUES(seq_Customer.NEXTVAL,'James','46, Lane 8','Chicago','F','42','6690893123');


8.CREATE SEQUENCE seq_master START WITH 2001
INCREMENT BY 1;
INSERT INTO AccountsMaster VALUES(seq_master.NEXTVAL,'1003','NRI','5000',);
INSERT INTO AccountsMaster VALUES(seq_master.NEXTVAL,'1001','IND','7000');
INSERT INTO AccountsMaster VALUES(seq_master.NEXTVAL,'1000','IND','9000');
INSERT INTO AccountsMaster VALUES(seq_master.NEXTVAL,'1002','NRI','4000');


UPDATE AccountsMaster
SET LedgerBalance='8000' WHERE AccountNumber='2004';

UPDATE AccountsMaster
SET AccountType='IND' WHERE AccountNumber='2004';

//select
1.SELECT * FROM AccountsMaster;
2.SELECT * FROM AccountsMaster WHERE LedgerBalance>5000;
3.SELECT * FROM  AccountsMaster WHERE AccountType='NRI';
4.SELECT Cust_Name FROM customer1  WHERE Address2='New York';