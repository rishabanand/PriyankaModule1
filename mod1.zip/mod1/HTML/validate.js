var qArray = [["B.E","B.Sc","B.Tech"],["M.Tech","M.Sc","MBA"]]
function populateQualification(){
var grad = frm1.rdGrad.value;
var qualification = frm1.txtQual;
//var grad = document.getElementById("rdGrad").value;
if(grad =='UG'){
for(i=0;i<qArray[0].length;i++){
var option = new Option();
option.text=qArray[0][i];
qualification.options[i] = option;
}
}else
{
for(i=0;i<qArray[1].length;i++){
var option = new Option();
option.text=qArray[1][i];
qualification.options[i] = option;
}
}
}
 

function showData()
 {
var win = window.open();
var uname = frm1.name.value;
var dobStr= frm1.date.value;
var phone = frm1.phno.value;
var email = frm1.email.value;
var grad = frm1.rdGrad.value;
var qualification = frm1.txtQual.value;


var today = new Date();
var dob = new Date(dobStr);
var age = today.getYear()-dob.getYear()

win.document.write("<br/>Name:"+uname);	  
win.document.write("<br/>Age:"+age+"years");
win.document.write("<br/>Phone NUumber:"+phone); 
win.document.write("<br/>Email:"+email);
win.document.write("<br/>Graduation Level:"+grad); 
win.document.write("<br/>Qualification:"+qualification);
	  
 }
 
