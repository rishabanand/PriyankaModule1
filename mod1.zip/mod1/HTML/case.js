var qArray[["B.Sc""B.tech"],["M.tech",M.Sc]
function populateQualification(){
var grad=frm1.rdGrad.value;
var qualification = frm1.txtQual;
//var grad = document.getElementById("rdGrad").value;
if(grad =='UG'){
for(i=0;i<qArray[0].length;i++){
var option = new Option();
option.text=qArray[0][i];
qualifications.options[i]= option;
}
}else
{
for(i=0;i<qArray[1].length;i++){
var option = new Option();
option.text=qArray[1][i];
qualifications.options[i]= option;
}
}
