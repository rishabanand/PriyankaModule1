var qArray = [["television","Laptop","Machine"],["soap","powder"]]
var pricePerQuantity=0;
function populateCategory(){
var catgry = frm2.category.value;
var list = frm2.products;
//var catgry= document.getElementById("category").value;
if(catgry =='Electronics'){
for(i=0;i<qArray[0].length;i++){
var option = new Option();
option.text=qArray[0][i];
list.options[i] = option;
}
}else
{
for(i=0;i<qArray[1].length;i++){
var option = new Option();
option.text=qArray[1][i];
list.options[i] = option;
}
}
}
 
 function chooseProduct()
 {
 var productSelected=frm2.products.value;
 if(productSelected=='television')
 {
 pricePerQuantity = 20000;
 }
else if(productSelected=='laptop')
 {
 pricePerQuantity = 30000;
 }
else if(productSelected=='phone')
 {
 pricePerQuantity = 10000;
 }
 else if(productSelected=='soap')
 {
 pricePerQuantity = 40;
 }
 if(productSelected=='powder')
 {
 pricePerQuantity = 90;
 }
 
 return pricePerQuantity;
 }





function showData()
 {
var win = window.open();
var category = frm2.category.value;
var product= frm2.products.value;
var quantity= frm2.qty.value;
var totalprice = frm2.price.value;


win.document.write("<br/>Category:"+category);	  
win.document.write("<br/>Product:"+product);
win.document.write("<br/>Quantity:"+quantity); 
win.document.write("<br/>Total Price:"+totalprice);
	  
 }
 
function calculatePrice()
{

var quantity = frm2.qty.value;
var t = chooseProduct();

 var totalprice = t*quantity;
 frm2.price.value = totalprice;
 }