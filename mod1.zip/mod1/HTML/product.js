var qArray = [["Television","Laptop","Phone"],["Soap","Powder"]]
function populateCategory(){
var catgry = frm2.category.value;
var list = frm2.products;
//var catgry = document.getElementById("category").value;
if(catgry =='Electronics'){
for(i=0;i<qArray[0].length;i++){
var option = new Option();
option.text=qArray[0][i];
list.options[i] = option;
}
}else
{
for(i=0;i<qArray[1].length;i++){
var option = new Option();
option.text=qArray[1][i];
list.options[i] = option;
}
}
}


function calculatePrice()
{

}
 

/*function showData()
 {
var win = window.open();
var category = frm2.category.value;
var product= frm2.products.value;
var quantity= frm2.qty.value;
var  price = frm2.price.value;


win.document.write("<br/>Category:"+category);	  
win.document.write("<br/>Product:"+product);
win.document.write("<br/>Quantity:"+quantity); 
win.document.write("<br/>Total Price:"+price);
	  
 }*/
 
